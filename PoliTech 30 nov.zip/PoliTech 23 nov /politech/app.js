const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');



app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.json());

// Connessione al database
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'mikaela1', 
  database: 'login_db'
});

db.connect((err) => {
  if (err) {
    console.error('Errore di connessione al database:', err.stack);
    return;
  }
  console.log('Connesso al database MySQL');
});



// Funzione di autenticazione del token - assicurati che questa sia definita qui
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token non fornito' });
  }

  jwt.verify(token, 'segreto', (err, user) => {
    if (err) return res.status(403).json({ error: 'Token non valido' });
    req.user = user;
    next();
  });
}

// Rotta di login
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Username e password sono obbligatori' });
  }

  const query = 'SELECT * FROM users WHERE username = ?';
  db.execute(query, [username], (err, results) => {
    if (err) {
      console.error('Errore durante la query:', err);
      return res.status(500).json({ error: 'Errore interno del server' });
    }

    if (results.length === 0) {
      return res.status(400).json({ error: 'Username non trovato' });
    }

    const user = results[0];

    bcrypt.compare(password, user.password, (err, isMatch) => {
      if (err) {
        console.error('Errore durante il confronto della password:', err);
        return res.status(500).json({ error: 'Errore interno del server' });
      }

      if (isMatch) {
        const token = jwt.sign({ id: user.id, username: user.username }, 'segreto', { expiresIn: '1h' });
        return res.json({ token });
      } else {
        return res.status(400).json({ error: 'Password errata' });
      }
    });
  });
});

// Endpoint per visualizzare tutte le sedi (protetto)
app.get('/sedi', authenticateToken, (req, res) => {
  db.query('SELECT * FROM sedi', (err, results) => {
    if (err) return res.status(500).json({ error: 'Errore nel caricamento delle sedi' });
    res.json(results);
  });
});
// Endpoint per ottenere una sede specifica (protetto)
app.get('/sedi/:id', authenticateToken, (req, res) => {
    const { id } = req.params; // Ottieni l'ID dalla route
  
    db.query('SELECT * FROM sedi WHERE id = ?', [id], (err, results) => {
      if (err) return res.status(500).json({ error: 'Errore nel recupero dei dati della sede' });
  
      if (results.length === 0) {
        return res.status(404).json({ error: 'Sede non trovata' }); // Se la sede non esiste
      }
  
      res.json(results[0]); // Restituisce solo il primo risultato, poiché l'ID è unico
    });
  });
// Endpoint per aggiungere una nuova sede (protetto)
app.post('/sedi', authenticateToken, (req, res) => {
  const { nome, localita, numero_persone, posti_disponibili } = req.body;
  db.query(
    'INSERT INTO sedi (nome, localita, numero_persone, posti_disponibili) VALUES (?, ?, ?, ?)',
    [nome, localita, numero_persone, posti_disponibili],
    (err, result) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ id: result.insertId, nome, localita, numero_persone, posti_disponibili });
    }
  );
});

// Endpoint per modificare una sede esistente (protetto)
app.put('/sedi/:id', authenticateToken, (req, res) => {
  const { id } = req.params;
  const { nome, localita, numero_persone, posti_disponibili } = req.body;
  db.query(
    'UPDATE sedi SET nome = ?, localita = ?, numero_persone = ?, posti_disponibili = ? WHERE id = ?',
    [nome, localita, numero_persone, posti_disponibili, id],
    (err) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ id, nome, localita, numero_persone, posti_disponibili });
    }
  );
});

// Endpoint per rimuovere una sede (protetto)
app.delete('/sedi/:id', authenticateToken, (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM sedi WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: `Sede con ID ${id} eliminata con successo.` });
  });
});
// Rotta per ottenere il numero degli asset
app.get('/api/assets/count', (req, res) => {
  // Esegui una query per ottenere il numero di asset
  const sql = 'SELECT COUNT(*) AS asset_count FROM assets';

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Errore nella query: ', err);
      return res.status(500).json({ error: 'Errore nella query del database' });
    }
    // Restituisci il numero degli asset come risposta JSON
    res.json(results[0]);
  });
});

// Rotta per ottenere il numero dei dipendenti
app.get('/api/dipendenti/count', (req, res) => {
  // Esegui una query per ottenere il numero di dipendenti
  const sql = 'SELECT COUNT(*) AS dipendenti_count FROM dipendenti';

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Errore nella query: ', err);
      return res.status(500).json({ error: 'Errore nella query del database' });
    }
    // Restituisci il numero 
// Rotta per ottenere il numero dei dipendenti come risposta JSON
    res.json(results[0]);
  });
});

// Rotta per ottenere il numero dei dipendenti
app.get('/api/accessori/count', (req, res) => {
  // Esegui una query per ottenere il numero di dipendenti
  const sql = 'SELECT COUNT(*) AS accessori_count FROM accessori';

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Errore nella query: ', err);
      return res.status(500).json({ error: 'Errore nella query del database' });
    }
    // Restituisci il numero 
// Rotta per ottenere il numero dei dipendenti come risposta JSON
    res.json(results[0]);
  });
});
// Rotta per ottenere il numero dei dipendenti
app.get('/api/lic/count', (req, res) => {
  // Esegui una query per ottenere il numero di dipendenti
  const sql = 'SELECT COUNT(*) AS lic_count FROM lic';

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Errore nella query: ', err);
      return res.status(500).json({ error: 'Errore nella query del database' });
    }
    // Restituisci il numero 
// Rotta per ottenere il numero dei dipendenti come risposta JSON
    res.json(results[0]);
  });
});

// Endpoint per ottenere le azioni recenti
app.get('/api/recent-actions', (req, res) => {
  const query = 'SELECT * FROM actions ORDER BY date DESC LIMIT 10'; // Preleva le ultime 10 azioni
  db.query(query, (err, results) => {
      if (err) {
          console.error('Errore nella query:', err);
          res.status(500).send('Errore nel recupero dei dati');
          return;
      }
      res.json(results); // Restituisce i risultati come JSON
  });
});

//// 
// Endpoint per ottenere lo stato degli asset
app.get('/api/asset-status', (req, res) => {
  const query = `
      SELECT status, COUNT(*) as count
      FROM assets
      GROUP BY status
  `;

  db.query(query, (err, results) => {
      if (err) {
          console.error('Errore durante il recupero dei dati:', err);
          return res.status(500).json({ error: 'Errore nel server' });
      }

      // Converti i dati in un formato compatibile con Chart.js
      const labels = [];
      const data = [];
      results.forEach(row => {
          labels.push(row.status); // 'Attivi', 'Inattivi', ecc.
          data.push(row.count);    // Quantità di asset per ogni stato
      });

      res.json({ labels, data });
  });
});

app.get('/api/assets', (req, res) => {
  const { status, sede } = req.query; // Ottieni i parametri dalla query string
  const { priceSort } = req.query; 

  // Crea una query di base
  let sql = 'SELECT * FROM assets WHERE 1=1';
  const params = [];

  // Aggiungi i filtri, se presenti
  if (status) {
    sql += ' AND status = ?';
    params.push(status);
  }
  if (sede) {
    sql += ' AND sede = ?';
    params.push(sede);

    
  }
  if (priceSort) {
    if (priceSort === 'asc') {
      sql += ' ORDER BY costo ASC';
    } else if (priceSort === 'desc') {
      sql += ' ORDER BY costo DESC';
    }
  }
  // Esegui la query con i filtri
  db.query(sql, params, (err, results) => {
    if (err) {
      console.error('Errore durante il recupero dei dati:', err);
      res.status(500).send('Errore server');
      return;
    }
    res.json(results); // Rispondi con i dati filtrati
  });
});

//
//
// Aggiungi nuovo asset
app.post('/api/assets', (req, res) => {
  const { name, status, data_inserimento, sede, data_acquisto, costo } = req.body;

  const sql = `
    INSERT INTO assets (name, status, data_inserimento, sede, data_acquisto, costo)
    VALUES (?, ?, ?, ?, ?, ?)
  `;

  db.query(sql, [name, status, data_inserimento, sede, data_acquisto, costo], (err, results) => {
    if (err) {
      console.error('Errore durante l\'aggiunta dell\'asset:', err);
      return res.status(500).send('Errore server');
    }
    res.status(201).send({ id: results.insertId, message: 'Asset aggiunto con successo' });
  });
});

// Modifica un asset
app.put('/api/assets/:id', (req, res) => {
  const { id } = req.params;
  const { name, status, data_inserimento, sede, data_acquisto, costo } = req.body;

  const sql = `
    UPDATE assets
    SET name = ?, status = ?, data_inserimento = ?, sede = ?, data_acquisto = ?, costo = ?
    WHERE id = ?
  `;

  db.query(sql, [name, status, data_inserimento, sede, data_acquisto, costo, id], (err, results) => {
    if (err) {
      console.error('Errore durante la modifica dell\'asset:', err);
      return res.status(500).send('Errore server');
    }
    res.send({ message: 'Asset aggiornato con successo' });
  });
});

// Rimuovi un asset
app.delete('/api/assets/:id', (req, res) => {
  const { id } = req.params;

  const sql = 'DELETE FROM assets WHERE id = ?';

  db.query(sql, [id], (err, results) => {
    if (err) {
      console.error('Errore durante l\'eliminazione dell\'asset:', err);
      return res.status(500).send('Errore server');
    }
    res.send({ message: 'Asset eliminato con successo' });
  });
});


// Rotta per ottenere il numero di asset per sede
app.get('/api/assets/count-by-sede', (req, res) => {
  const sql = `
    SELECT sede, COUNT(*) AS asset_count
    FROM assets
    GROUP BY sede
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Errore nella query:', err);
      return res.status(500).json({ error: 'Errore nella query del database' });
    }
    res.json(results); // Restituisce il numero di asset per sede
  });
});


// Endpoint per ottenere i dati per il grafico
app.get('/costi', (req, res) => {
  const sql = `
    SELECT 
      YEAR(data_acquisto) AS anno, 
      MONTH(data_acquisto) AS mese, 
      SUM(costo) AS totale_costo
    FROM assets
    GROUP BY YEAR(data_acquisto), MONTH(data_acquisto)
    ORDER BY anno, mese
  `;

  db.query(sql, (err, results) => {
    if (err) {
      res.status(500).send('Errore durante l\'esecuzione della query');
    } else {
      res.json(results);  // Risponde con i dati in formato JSON
    }
  });
});

// Avvia il server sulla porta 3000
app.listen(3000, () => {
  console.log('Server in ascolto sulla porta 3000');
});
