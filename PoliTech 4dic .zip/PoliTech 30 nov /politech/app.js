const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');



app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.json());

// Connessione al database
const db = mysql.createConnection({
  host: '127.0.0.1',
  user: 'claudio',
  password: 'ciao2', 
  database: 'database30nov'
});

db.connect((err) => {
  if (err) {
    console.error('Errore di connessione al database:', err.stack);
    return;
  }
  console.log('Connesso al database MySQL');
});



// Funzione di autenticazione del token - assicurati che questa sia definita qui
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token non fornito' });
  }

  jwt.verify(token, 'segreto', (err, user) => {
    if (err) return res.status(403).json({ error: 'Token non valido' });
    req.user = user;
    next();
  });
}

// Rotta di login
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Username e password sono obbligatori' });
  }

  const query = 'SELECT * FROM users WHERE username = ?';
  db.execute(query, [username], (err, results) => {
    if (err) {
      console.error('Errore durante la query:', err);
      return res.status(500).json({ error: 'Errore interno del server' });
    }

    if (results.length === 0) {
      return res.status(400).json({ error: 'Username non trovato' });
    }

    const user = results[0];

    bcrypt.compare(password, user.password, (err, isMatch) => {
      if (err) {
        console.error('Errore durante il confronto della password:', err);
        return res.status(500).json({ error: 'Errore interno del server' });
      }

      if (isMatch) {
        const token = jwt.sign({ id: user.id, username: user.username }, 'segreto', { expiresIn: '1h' });
        return res.json({ token });
      } else {
        return res.status(400).json({ error: 'Password errata' });
      }
    });
  });
});



// SEDI
//
// Endpoint per visualizzare tutte le sedi (protetto)
app.get('/sedi', authenticateToken, (req, res) => {
  db.query('SELECT * FROM sedi', (err, results) => {
    if (err) return res.status(500).json({ error: 'Errore nel caricamento delle sedi' });
    res.json(results);
  });
});
// Endpoint per ottenere una sede specifica (protetto)
app.get('/sedi/:id', authenticateToken, (req, res) => {
    const { id } = req.params; // Ottieni l'ID dalla route
  
    db.query('SELECT * FROM sedi WHERE id = ?', [id], (err, results) => {
      if (err) return res.status(500).json({ error: 'Errore nel recupero dei dati della sede' });
  
      if (results.length === 0) {
        return res.status(404).json({ error: 'Sede non trovata' }); // Se la sede non esiste
      }
  
      res.json(results[0]); // Restituisce solo il primo risultato, poiché l'ID è unico
    });
  });
// Endpoint per aggiungere una nuova sede (protetto)
app.post('/sedi', authenticateToken, (req, res) => {
  const { nome, localita, numero_persone, posti_disponibili } = req.body;
  db.query(
    'INSERT INTO sedi (nome, localita, numero_persone, posti_disponibili) VALUES (?, ?, ?, ?)',
    [nome, localita, numero_persone, posti_disponibili],
    (err, result) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ id: result.insertId, nome, localita, numero_persone, posti_disponibili });
    }
  );
});

// Endpoint per modificare una sede esistente (protetto)
app.put('/sedi/:id', authenticateToken, (req, res) => {
  const { id } = req.params;
  const { nome, localita, numero_persone, posti_disponibili } = req.body;
  db.query(
    'UPDATE sedi SET nome = ?, localita = ?, numero_persone = ?, posti_disponibili = ? WHERE id = ?',
    [nome, localita, numero_persone, posti_disponibili, id],
    (err) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ id, nome, localita, numero_persone, posti_disponibili });
    }
  );
});

// Endpoint per rimuovere una sede (protetto)
app.delete('/sedi/:id', authenticateToken, (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM sedi WHERE id = ?', [id], (err) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: `Sede con ID ${id} eliminata con successo.` });
  });
});


// Rotte per ottenere le quantità di elementi
//
// Rotta per ottenere il numero degli asset
app.get('/api/assets/count', (req, res) => {
  // Esegui una query per ottenere il numero di asset
  const sql = 'SELECT COUNT(*) AS asset_count FROM assets';

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Errore nella query: ', err);
      return res.status(500).json({ error: 'Errore nella query del database' });
    }
    // Restituisci il numero degli asset come risposta JSON
    res.json(results[0]);
  });
});

// Rotta per ottenere il numero dei dipendenti
app.get('/api/dipendenti/count', (req, res) => {
  // Esegui una query per ottenere il numero di dipendenti
  const sql = 'SELECT COUNT(*) AS dipendenti_count FROM dipendenti';

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Errore nella query: ', err);
      return res.status(500).json({ error: 'Errore nella query del database' });
    }
    // Restituisci il numero 
    // Rotta per ottenere il numero dei dipendenti come risposta JSON
    res.json(results[0]);
  });
});

// Rotta per ottenere il numero degli  accessori
app.get('/api/accessori/count', (req, res) => {
  // Esegui una query per ottenere il numero di accessori
  const sql = 'SELECT COUNT(*) AS accessori_count FROM accessori';

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Errore nella query: ', err);
      return res.status(500).json({ error: 'Errore nella query del database' });
    }
    // Restituisci il numero 
    // Rotta per ottenere il numero degli accessori come risposta JSON
    res.json(results[0]);
  });
});

// Rotta per ottenere il numero delle licenze
app.get('/api/lic/count', (req, res) => {
  // Esegui una query per ottenere il numero delle licenze
  const sql = 'SELECT COUNT(*) AS lic_count FROM lic';

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Errore nella query: ', err);
      return res.status(500).json({ error: 'Errore nella query del database' });
    }
    // Restituisci il numero 
    // Rotta per ottenere il numero delle licenze come risposta JSON
    res.json(results[0]);
  });
});
//


// Endpoint per ottenere le azioni recenti
app.get('/api/recent-actions', (req, res) => {
  const query = 'SELECT * FROM actions ORDER BY date DESC LIMIT 10'; // Preleva le ultime 10 azioni
  db.query(query, (err, results) => {
      if (err) {
          console.error('Errore nella query:', err);
          res.status(500).send('Errore nel recupero dei dati');
          return;
      }
      res.json(results); // Restituisce i risultati come JSON
  });
});


// Endpoint per ottenere lo stato degli asset
app.get('/api/asset-status', (req, res) => {
  const query = `
      SELECT status, COUNT(*) as count
      FROM assets
      GROUP BY status
  `;

  db.query(query, (err, results) => {
      if (err) {
          console.error('Errore durante il recupero dei dati:', err);
          return res.status(500).json({ error: 'Errore nel server' });
      }

      // Converti i dati in un formato compatibile con Chart.js
      const labels = [];
      const data = [];
      results.forEach(row => {
          labels.push(row.status); // 'Attivi', 'Inattivi', ecc.
          data.push(row.count);    // Quantità di asset per ogni stato
      });

      res.json({ labels, data });
  });
});

//Ottenere tutti gli assets
app.get('/api/assets', (req, res) => {
  const { status, sede } = req.query; // Ottieni i parametri dalla query string
  const { priceSort } = req.query; 

  // Crea una query di base
  let sql = 'SELECT * FROM assets WHERE 1=1';
  const params = [];

  // Aggiungi i filtri, se presenti
  if (status) {
    sql += ' AND status = ?';
    params.push(status);
  }
  if (sede) {
    sql += ' AND sede = ?';
    params.push(sede);

    
  }
  if (priceSort) {
    if (priceSort === 'asc') {
      sql += ' ORDER BY costo ASC';
    } else if (priceSort === 'desc') {
      sql += ' ORDER BY costo DESC';
    }
  }
  // Esegui la query con i filtri
  db.query(sql, params, (err, results) => {
    if (err) {
      console.error('Errore durante il recupero dei dati:', err);
      res.status(500).send('Errore server');
      return;
    }
    res.json(results); // Rispondi con i dati filtrati
  });
});



//ASSET
//
// Aggiungi nuovo asset
app.post('/api/assets', (req, res) => {
  const { name, status, data_inserimento, sede, data_acquisto, costo } = req.body;

  const sql = `
    INSERT INTO assets (name, status, data_inserimento, sede, data_acquisto, costo)
    VALUES (?, ?, ?, ?, ?, ?)
  `;

  db.query(sql, [name, status, data_inserimento, sede, data_acquisto, costo], (err, results) => {
    if (err) {
      console.error('Errore durante l\'aggiunta dell\'asset:', err);
      return res.status(500).send('Errore server');
    }
    res.status(201).send({ id: results.insertId, message: 'Asset aggiunto con successo' });
  });
});

// Modifica un asset
app.put('/api/assets/:id', (req, res) => {
  const { id } = req.params;
  const { name, status, data_inserimento, sede, data_acquisto, costo } = req.body;

  const sql = `
    UPDATE assets
    SET name = ?, status = ?, data_inserimento = ?, sede = ?, data_acquisto = ?, costo = ?
    WHERE id = ?
  `;

  db.query(sql, [name, status, data_inserimento, sede, data_acquisto, costo, id], (err, results) => {
    if (err) {
      console.error('Errore durante la modifica dell\'asset:', err);
      return res.status(500).send('Errore server');
    }
    res.send({ message: 'Asset aggiornato con successo' });
  });
});

// Rimuovi un asset
app.delete('/api/assets/:id', (req, res) => {
  const { id } = req.params;

  const sql = 'DELETE FROM assets WHERE id = ?';

  db.query(sql, [id], (err, results) => {
    if (err) {
      console.error('Errore durante l\'eliminazione dell\'asset:', err);
      return res.status(500).send('Errore server');
    }
    res.send({ message: 'Asset eliminato con successo' });
  });
});


// Rotta per ottenere il numero di asset per sede
app.get('/api/assets/count-by-sede', (req, res) => {
  const sql = `
    SELECT sede, COUNT(*) AS asset_count
    FROM assets
    GROUP BY sede
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Errore nella query:', err);
      return res.status(500).json({ error: 'Errore nella query del database' });
    }
    res.json(results); // Restituisce il numero di asset per sede
  });
});


// Endpoint per ottenere i dati per il grafico
app.get('/costi', (req, res) => {
  const sql = `
    SELECT 
      YEAR(data_acquisto) AS anno, 
      MONTH(data_acquisto) AS mese, 
      SUM(costo) AS totale_costo
    FROM assets
    GROUP BY YEAR(data_acquisto), MONTH(data_acquisto)
    ORDER BY anno, mese
  `;

  db.query(sql, (err, results) => {
    if (err) {
      res.status(500).send('Errore durante l\'esecuzione della query');
    } else {
      res.json(results);  // Risponde con i dati in formato JSON
    }
  });
});


// Rotta per ottenere il numero di dipendenti per sede
app.get('/api/dipendenti/count-by-sede', (req, res) => {
  const sql = `
    SELECT id_sede, COUNT(*) AS dipendenti_count
    FROM dipendenti
    GROUP BY id_sede
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Errore nella query:', err);
      return res.status(500).json({ error: 'Errore nella query del database' });
    }
    res.json(results); // Restituisce il numero di dipendenti per sede
  });
});



//DIPENDENTI
//
// Aggiungi dipendente
app.post('/api/dipendenti', (req, res) => {
  const { name, cognome, email, grado, costo_acquisto, id_accessori, id_sede } = req.body;

  const sql = `
    INSERT INTO dipendenti (name, cognome, email, grado, costo_acquisto, id_accessori, id_sede)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `;

  db.query(sql, [name, cognome, email, grado, costo_acquisto, id_accessori, id_sede], (err, results) => {
    if (err) {
      console.error('Errore durante l\'aggiunta del dipendente:', err);
      return res.status(500).send('Errore server');
    }
    res.status(201).send({ id: results.insertId, message: 'Dipendente aggiunto con successo' });
  });
});

// Modifica dipendente
app.put('/api/dipendenti/:id', (req, res) => {
  const { id } = req.params;
  const { name, cognome, email, grado, costo_acquisto, id_accessori, id_sede } = req.body;

  const sql = `
    UPDATE dipendenti
    SET name = ?, cognome = ?, email = ?, grado = ?, costo_acquisto = ?, id_accessori = ?, id_sede = ?
    WHERE id_dip = ?
  `;

  db.query(sql, [name, cognome, email, grado, costo_acquisto, id_accessori, id_sede, id], (err, results) => {
    if (err) {
      console.error('Errore durante la modifica del dipendente:', err);
      return res.status(500).send('Errore server');
    }
    res.send({ message: 'Dipendente aggiornato con successo' });
  });
});

// Rimuovi dipendente
app.delete('/api/dipendenti/:id', (req, res) => {
  const { id } = req.params;

  const sql = 'DELETE FROM dipendenti WHERE id_dip = ?';

  db.query(sql, [id], (err, results) => {
    if (err) {
      console.error('Errore durante l\'eliminazione del dipendente:', err);
      return res.status(500).send('Errore server');
    }
    res.send({ message: 'Dipendente eliminato con successo' });
  });
});

// Visualizza tutti i dipendenti
app.get('/api/dipendenti', (req, res) => {
  const { grado, id_sede } = req.query; // Ottieni i parametri dalla query string
  const { nameSort } = req.query;

  // Crea una query di base
  let sql = 'SELECT * FROM dipendenti WHERE 1=1';
  const params = [];

  // Aggiungi i filtri, se presenti
  if (grado) {
    sql += ' AND grado = ?';
    params.push(grado);
  }
  if (id_sede) {
    sql += ' AND id_sede = ?';
    params.push(id_sede);
  }
  if (nameSort) {
    if (nameSort === 'asc') {
      sql += ' ORDER BY name ASC';
    } else if (nameSort === 'desc') {
      sql += ' ORDER BY name DESC';
    }
  }

  // Stampa la query generata per il debug
  console.log('SQL Query:', sql);
  console.log('Parameters:', params);

  // Esegui la query con i filtri
  db.query(sql, params, (err, results) => {
    if (err) {
      console.error('Errore durante il recupero dei dati:', err.message);
      res.status(500).send('Errore server');
      return;
    }
    res.json(results); // Rispondi con i dati filtrati
  });
});


// SEDI

//Aggiunta sedi
app.post('/api/sedi', (req, res) => {
  const { nome, localita, numero_persone, posti_disponibili } = req.body;

  const sql = `
    INSERT INTO sedi (nome, localita, numero_persone, posti_disponibili)
    VALUES (?, ?, ?, ?)
  `;

  db.query(sql, [nome, localita, numero_persone, posti_disponibili], (err, results) => {
    if (err) {
      console.error('Errore durante l\'aggiunta della sede:', err);
      return res.status(500).send('Errore server');
    }
    res.status(201).send({ id: results.insertId, message: 'Sede aggiunta con successo' });
  });
});

// Modifica sedi 
app.put('/api/sedi/:id', (req, res) => {
  const { id } = req.params;
  const { nome, localita, numero_persone, posti_disponibili } = req.body;

  const sql = `
    UPDATE sedi
    SET nome = ?, localita = ?, numero_persone = ?, posti_disponibili = ?
    WHERE id = ?
  `;

  db.query(sql, [nome, localita, numero_persone, posti_disponibili, id], (err, results) => {
    if (err) {
      console.error('Errore durante la modifica della sede:', err);
      return res.status(500).send('Errore server');
    }
    res.send({ message: 'Sede aggiornata con successo' });
  });
});

// Rimuovi sedi 
app.delete('/api/sedi/:id', (req, res) => {
  const { id } = req.params;

  const sql = 'DELETE FROM sedi WHERE id = ?';

  db.query(sql, [id], (err, results) => {
    if (err) {
      console.error('Errore durante l\'eliminazione della sede:', err);
      return res.status(500).send('Errore server');
    }

    if (results.affectedRows === 0) {
      // Nessuna riga eliminata
      return res.status(404).send({ message: 'Sede non trovata' });
    }

    res.send({ message: 'Sede eliminata con successo' });
  });
});

// Visualizza tutte le sedi
app.get('/api/sedi', (req, res) => {
  const { localita, postiMin, postiMax } = req.query; // Ottieni i parametri dalla query string
  const { nomeSort } = req.query;

  // Crea una query di base
  let sql = 'SELECT * FROM sedi WHERE 1=1';
  const params = [];

  // Aggiungi i filtri, se presenti
  if (localita) {
    sql += ' AND localita = ?';
    params.push(localita);
  }
  if (postiMin) {
    sql += ' AND posti_disponibili >= ?';
    params.push(parseInt(postiMin));
  }
  if (postiMax) {
    sql += ' AND posti_disponibili <= ?';
    params.push(parseInt(postiMax));
  }
  if (nomeSort) {
    if (nomeSort === 'asc') {
      sql += ' ORDER BY nome ASC';
    } else if (nomeSort === 'desc') {
      sql += ' ORDER BY nome DESC';
    }
  }

  // Stampa la query generata per il debug
  console.log('SQL Query:', sql);
  console.log('Parameters:', params);

  // Esegui la query con i filtri
  db.query(sql, params, (err, results) => {
    if (err) {
      console.error('Errore durante il recupero delle sedi:', err.message);
      res.status(500).send('Errore server');
      return;
    }
    res.json(results); // Rispondi con i dati filtrati
  });
});


// Avvia il server sulla porta 3000
app.listen(3000, () => {
  console.log('Server in ascolto sulla porta 3000');
});


